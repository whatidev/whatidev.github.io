---
title: Facebook
category: Contact Syncing
order: 1
---

Sync your Facebook contacts with ChatApp. Any of your Facebook friends with ChatApp accounts are automatically added to your contact list!

> Signing up with Facebook automatically starts syncing contacts.

To sync your contacts:

1. Open your *User Settings*
2. Select the **Connect Facebook** button
3. Authorise ChatApp

![](//placehold.it/800x600)